import re
import sys


def main():
    print(validate(input("IPv4 Address: ")))


def validate(ip):
    try:
        m = ip.split(".")
        x = []
        count = 0
        for i in m:
            x.append(int(i))
        for j in x:
            if j >= 0 and j <=255:
                count += 1
        if count == 4:
            return True
        else:
            return False
    except ValueError:
        return False


if __name__ == "__main__":
    main()