from numb3rs import validate

def test_numb3rs():
    assert validate("cat") == False
    assert validate("255.255.255.255") == True
    assert validate("1.290.1.1") == False