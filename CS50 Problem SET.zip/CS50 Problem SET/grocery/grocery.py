def main () :
    item = ""
    new = []
    items = []
    while True :
        try :
            item = input()
            new.append(item)
            if item in items :
                continue
            else :
                items.append(item)
        except EOFError :
            break
    list(items,new)

def list(x,y) :
    n = len(x)
    m = len(y)
    count_items = []
    for i in range (0,n) :
        count = 0
        for j in range (0,m) :
            if x[i] == y[j] :
                count += 1
        count_items.append(count)
    sort(x,count_items)

def sort(c,d) :
    for i in range(0,len(c) - 1) :
        if c[i] < c[i+1] :
            continue
        else :
            c[i+1],c[i] = c[i],c[i+1]
            d[i+1],d[i] = d[i],d[i+1]
    print_grocerylist(c,d)

def print_grocerylist(a,b) :
    for i in range(0,len(a)) :
        print(b[i],a[i].upper())


main()

