
def main():
    expression = input("Enter an expression: ")
    print(gauge(convert(expression)))



def convert(fraction):
    while True:
        try:
            num = fraction.split("/")
            numerator = int(num[0])
            denominator = int(num[1])
            p = (numerator / denominator)
            if p <= 1:
                f = int(p * 100)
                return f
            else :
                expression = input("Enter an expression: ")
                pass

        except (ValueError, IndexError, ZeroDivisionError):
                raise




def gauge(percentage):
    if percentage >= 99 :
        return ("F")
    elif percentage <= 1 :
        return ("E")
    else :
        return f"{percentage}%"


if __name__ == "__main__":
    main()