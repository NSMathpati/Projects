def main () :
    greet = list(input("Greetings: ").strip().split())
    print(f"${value(greet[0])}")

def value(answer) :
    word = answer
    if "Hello" in word:
        return 0
    elif word[0] == 'H':
        return 20
    else:
        return 100

if __name__ == "__main__":
    main()