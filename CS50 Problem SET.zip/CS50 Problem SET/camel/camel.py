def main() :
    name = input("What is your name: ")
    camel(name)

def camel(string) :
    change = ""
    for i in  string :
        if i.isupper() :
            change +=  '_' + i.lower()
        else :
            change += i
    print(change)

main()