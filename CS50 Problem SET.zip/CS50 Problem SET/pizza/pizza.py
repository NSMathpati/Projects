import sys
import csv
from tabulate import tabulate

def main():
    if len(sys.argv) < 2:
        sys.exit("Too few command-line arguments")
    elif len(sys.argv) > 2:
        sys.exit("Too many command-line arguments")
    else :
        extension = sys.argv[1]
        row = extension.rstrip().split(".")
        if row[1] != "csv":
            sys.exit("Not a CSV file")
        else :
            table = []
            with open(extension) as file:
                reader = csv.reader(file)
                for row in reader :
                    table.append(row)
            print(tabulate(table[1:], headers = table[0], tablefmt="grid"))

if __name__ == "__main__":
    main()
