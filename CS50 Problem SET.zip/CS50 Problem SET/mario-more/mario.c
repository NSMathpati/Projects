#include <cs50.h>
#include <stdio.h>
void mariomore(int height)
{
    // Loop that runs through the height of the pyramid to zero
    for (int i = height; i > 0; i--)
    {
        // To print out the spaces on the left before starting the pyramid
        for (int j = 1; j < i; j++)
        {
            printf(" ");
        }
        // Prints out #'s as per the required pattern in the mario game
        for (int k = height; k >= i; k --)
        {
            printf("#");
        }
        printf("  ");// This is the space between the two pyramids
        // Loop that runs and prints out the other pattern of the pyramid accordingly
        for (int m = height; m >= i; m--)
        {
            printf("#");
        }
        printf("\n");
    }
}

int main(void)
{
    // asking user for input , like the height of the pyramid he would like to see
    int pyheight = get_int("What is the height of the pyramid?\n");
    if (pyheight >= 1 && pyheight <= 8)// Checks if the given user input is within range
    {
        mariomore(pyheight);
    }
    else
    {
        // Loop to promt user for input, if the user input is not within the range
        while (pyheight < 1 || pyheight > 8)
        {
            int newheight = get_int("What is the height of the pyramid>\n");
            // Checks again if the user input is within range
            if (newheight >= 1 && newheight <= 8)
            {
                mariomore(newheight);
                break;// Exits the loop if the new height given by the user is within range.
            }
            // If not the loop continues and the loop promts the user for new input over and over again
            else
            {
                continue;
            }
        }
    }
}