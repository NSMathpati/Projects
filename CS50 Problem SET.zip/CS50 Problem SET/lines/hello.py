#This program says hello to the user

name = input()
print(f"Hello {name}, how are you ?")