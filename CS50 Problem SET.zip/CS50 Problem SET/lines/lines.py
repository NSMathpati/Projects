import sys

lines = 0
if len(sys.argv) < 2 :
    sys.exit("Too few command-line arguments")
elif len(sys.argv) > 2 :
    sys.exit("Too many command-line arguments")
else :
    extension = sys.argv[1]
    row = extension.rstrip().split(".")
    if row[1] != "py":
        sys.exit("Not a python file")
    else :
        with open(sys.argv[1]) as file:
            for line in file:
                if line.isspace() or line.lstrip().startswith('#'):
                    lines += 0
                else:
                    lines += 1

print(lines)