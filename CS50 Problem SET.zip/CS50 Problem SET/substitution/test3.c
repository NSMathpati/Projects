#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

int main(int argc, string argv[])
{
    string key = argv[1];
    char cletter = 'A',ncletter = 'a';
    int count = 0;
    for (int i = 0; i < 26; i++)
    {
        if(strchr(key,cletter + i) != NULL || strchr(key,ncletter + i) != NULL)
        {
            count++;
        }
        else
        {
            break;
        }
    }
    if (count == 26)
    {
        printf("It works count : %i\n",count);
    }
    else
    {
        printf("It doesnt work count : %i\n",count);
    }
}
