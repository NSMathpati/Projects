#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

int main(int argc, string argv[])
{
    if (argc != 2)
    {
        printf("usage : ./substitution key\n");
        return 1;
    }
    if (strlen(argv[1]) != 26)
    {
        printf("Key must contain 26 characters\n");
    }
    else
    {
        string key = argv[1];
        char ch = 'A';
        char cnt = 65;
        char x,f;
        string text = get_string("Plaintext:  ");
        printf("Ciphertext: ");
        for (int i = 0, n = strlen(text); i < n; i++)
        {
            if (isalpha(text[i]))
            
            {
                while(text[i] != ch)
                {
                    ch = ch + 1;
                }
                x = ch - cnt;
                for (int j = 0; j <= 25; j++)
                {
                    if(x == j)
                    {
                        printf("%c", key[j]);
                        j = 0;
                        break;
                    }
                }
            }
            else
            {
                printf("%c",key[i]);
            }
        }
        printf("\n");
    }

}