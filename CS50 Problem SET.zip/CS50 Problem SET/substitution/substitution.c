#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

int main(int argc, string argv[])
{
    char cletter = 'A', ncletter = 'a';
    string key = argv[1];
    int count = 0;
    // Checks if there are more than or less than 2 arguments
    if (argc != 2)
    {
        printf("usage : ./substitution key\n");
        return 1;
    }
    // Checks if there are 26 characters in the argument
    if (strlen(argv[1]) != 26)
    {
        printf("Key must contain 26 characters\n");
        return 1;
    }
    // This loop checks if all 26 alphabets are present in the given key
    for (int i = 0; i < 26; i++)
    {
        if (strchr(key, cletter + i) != NULL || strchr(key, ncletter + i) != NULL)
        {
            count++;
        }
        else
        {
            break;
        }
    }
    // If the key contains all 26 alphabets then we cipher the given text
    if (count == 26)
    {
        char up = 'A', low = 'a', ucnt = 65, lcnt = 97;
        char ul;
        string text = get_string("Plaintext:  ");
        printf("ciphertext: ");
        for (int i = 0, n = strlen(text); i < n; i++)
        {
            // To check if given input has actual alphabets as characters and not numbers or special characters
            if (isalpha(text[i]))
            {
                if (isupper(text[i]))
                {
                    // To count which alphabet the given input has and go to the corresponding numberth of character on the key
                    while (text[i] != up)
                    {
                        up = up + 1;
                    }
                    ul = up - ucnt;
                    for (int j = 0; j <= 25; j++)
                    {
                        if (ul == j)
                        {
                            printf("%c", toupper(key[j]));
                            j = 0;
                            break;
                        }
                    }
                }
                else if (islower(text[i]))
                {
                    while (text[i] != low)
                    {
                        low = low + 1;
                    }
                    ul = low - lcnt;
                    for (int j = 0; j <= 25; j++)
                    {
                        if (ul == j)
                        {
                            printf("%c", tolower(key[j]));
                            j = 0;
                            break;
                        }
                    }
                }
            }
            // If the character is not an alphabet then it simply just prints out the character as it is in the output.
            else
            {
                printf("%c", text[i]);
            }

        }
        printf("\n");
        return 0;
    }
    // If key does not contain all 26 alphabets and has repeated alphabets in it.
    else
    {
        printf("Key must contain 26 characters\n");
        return 1;
    }
}