def main () :
    greet = list(input("Greetings: ").strip().split())
    reward(greet)

def reward(answer) :
    word = answer[0]
    if word == "Hello"  or "Hello" in word:
        print("$0")
    elif word[0] == 'H':
        print("$20")
    else:
        print("$100")

main()