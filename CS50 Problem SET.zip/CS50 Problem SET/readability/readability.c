#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <ctype.h>

// Declaring different functions to calculates number of letters, words, sentences in a given text.
int number_ofletters(string text);
int number_ofwords(string text);
int number_ofsentences(string text);

int main(void)
{
    int letters, words, sentences, grade;
    float g, l, s;
    string text;
    text = get_string("Enter text : ");
    letters = number_ofletters(text); // Calling the function to calculate letters
    words = number_ofwords(text); // Calling the function that calculates words
    sentences = number_ofsentences(text); // Calling the function that calculates sentences
    l = ((float)letters) / ((float)words) * 100; // Number of letters per 100 words
    s = ((float)sentences / (float)words) * 100; // Number of sentences per 100 words
    g = 0.0588 * l - 0.296 * s - 15.8; // Coleman-Liau index
    grade = round(g);

    if (grade > 16)
    {
        printf("Grade 16+\n");
    }
    else if (grade < 1)
    {
        printf("Before Grade 1\n");
    }
    else
    {
        printf("Grade %i\n", grade);
    }
}
// Function that calculates number of letters in a given text
int number_ofletters(string text)
{
    int count = 0;
    for (int i = 0; i < strlen(text); i++)
    {
        if (isalpha(text[i]) != 0)
        {
            count++;
        }
    }
    return count;
}
// Function that calculates number of words in a given user input text.
int number_ofwords(string text)
{
    int count = 1;
    for (int i = 0; i < strlen(text); i++)
    {
        if (text[i] == ' ')
        {
            count++;
        }
    }
    return count;
}
// Function that calculates number of sentences in a given user input text.
int number_ofsentences(string text)
{
    int count = 0;
    for (int i = 0; i < strlen(text); i++)
    {
        if (text[i] == '.' || text[i] == '!' || text[i] == '?')
        {
            count++;
        }
    }
    return count;
}