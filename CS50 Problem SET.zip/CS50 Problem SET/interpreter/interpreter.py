def main() :
    math = input("Enter your math input: ")
    math = math.split(" ")
    x = float(math[0])
    y = math[1]
    z = float(math[2])
    if y == '+' :
        add(x,z)
    elif y == '-' :
        subtract(x,z)
    elif y == '*' :
        multiply(x,z)
    elif y == '/' :
        divide(x,z)

# Function that adds two numbers
def add(x,z):
    print(x + z)

# Function that subtracts two numbers
def subtract(x,z):
    print(x - z)

# Function to multiply two numbers
def multiply(x,z) :
    print(x * z)

#function that divides two numbers
def divide(x,z) :
    print(x / z)


main()
