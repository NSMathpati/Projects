from emoji import emojize
print(emojize(input()))

