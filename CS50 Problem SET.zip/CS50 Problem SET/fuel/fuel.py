def main() :
    expression = input("Enter an expression: ")
    expression = expression.split('/')
    data = []
    for i in expression :
        if i.isdigit():
            data.append(i)
    length = len(data)
    if length < 2 or length > 2:
        main()
    elif  data[1] == '0' or int(data[0]) > int(data[1]) :
        main()
    else :
        fuel(data)

def fuel (x) :
    y = int(x[0]) / int(x[1])
    y = round(y*100)
    if y >= 99 :
        print("F")
    elif y <= 1 :
        print("E")
    else :
        print(f"{y}%")

main()
