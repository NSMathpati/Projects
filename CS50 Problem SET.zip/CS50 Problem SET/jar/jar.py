class Jar:
    def __init__(self, capacity=12):
        if capacity < 0:
            raise ValueError("Please Enter a valid integer")
        self.jar = capacity
        self.csize = 0
    def __str__(self):
        sr = ""
        for _ in range(0,self.size):
            sr += "🍪"
        return sr

    def deposit(self, n):
        if n > self.jar or n + self.size > self.jar:
            raise ValueError("Capacity exceeded")
        self.csize += n

    def withdraw(self, n):
        if n > self.size:
            raise ValueError("Too many to withdraw")
        self.csize -= n
    @property
    def capacity(self):
        return self.jar

    @property
    def size(self):
        return self.csize

def main():
    cjar = Jar()
    cjar.deposit(12)
    cjar.withdraw(5)
    print(cjar)


if __name__ == "__main__":
    main()