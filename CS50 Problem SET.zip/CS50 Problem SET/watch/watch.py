import re
import sys


def main():
    print(parse(input("HTML: ")))


def parse(s):
    html = re.search(r"<iframe (.+)><\/iframe>",s)
    if html:
        link = re.search(r"(https?:\/\/(www\.)?youtube\.com\/embed\/((\w)+))",s)
        if link:
            url = link.groups()
            final = url[2]
            new_link = "https://youtu.be/"+final
            return new_link




if __name__ == "__main__":
    main()