#defining main function
def main () :
    answer = input("The answer to the Great Question of Life, the Universe and Everything is ")
    deepthought(answer)

#defining a function call deepthought that will return either yes or no
def deepthought (string) :
    string = string.lower().strip()
    if string == "42" or string == "forty two" or string == "forty-two" :
        print("Yes")
    else :
        print("No")


main()