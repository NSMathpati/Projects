def main () :
    amount = 50
    while(True) :
        print(f'Amount due: {(amount)}')
        due = int(input('Insert coins: '))
        if due == 25 or due == 10 or due == 5 :
            amount = amount - due
        if amount == 0 or amount < 0:
            print(f'Change owed: {abs(amount)}')
            break


main()