import sys
from PIL import Image,ImageOps

def main():
    if len(sys.argv) < 3 :
        sys.exit("Too few command-line arguments")
    elif len(sys.argv) > 3:
        sys.exit("Too many command-line arguments")
    else:
        ext1 = sys.argv[1].split(".")
        ext2 = sys.argv[2].split(".")
        if (ext1[1] not in ["jpg", "jpeg", "png"]) :
            sys.exit("Invalid input")
        elif (ext2[1] not in ["jpg", "jpeg", "png"]):
            sys.exit("Invalid output")
        elif ext1[1] != ext2[1]:
            sys.exit("Input and output have different extensions")
        else :
            input = Image.open(sys.argv[1])
            shirtf = Image.open("shirt.png")
            sizeof_shirt = shirtf.size
            resizeinput = ImageOps.fit(input, sizeof_shirt)
            resizeinput.paste(shirtf,shirtf)
            resizeinput.save(sys.argv[2])


if __name__ == "__main__":
    main()
