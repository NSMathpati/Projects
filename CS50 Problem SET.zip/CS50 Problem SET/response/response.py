import validators

email_address = validators.email(input("Whats your email? "))
if email_address:
    print("Valid")
else:
    print("Invalid")