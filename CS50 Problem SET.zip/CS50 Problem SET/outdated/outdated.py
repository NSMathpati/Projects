months_list = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"
]

while True :
    x = input("Enter Date: ").strip()
    try :
        month, date, year = x.split('/')
        if int(month) > 0 and int(month) <= 12 :
            if int(date) > 0 and int(date) <=31 :
                break

    except:
        try :
            m, d, y = x.split(" ")
            if ','  in x :
                for i in range(len(months_list)):
                    if m == months_list[i]:
                        month = i + 1
                        break

                date = d.replace(',',"")
                year = y
                if int(month) > 0 and int(month) <= 12 :
                    if int(date) > 0 and int(date) <=31 :
                        break
        except :
            print()
            pass


print(f"{year}-{int(month):02}-{int(date):02}")
