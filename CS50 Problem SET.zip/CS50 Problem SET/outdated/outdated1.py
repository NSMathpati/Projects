def main () :
    date = list(input().split('/'))
    change(date)

def change(date) :
    if (int(date[1]) < 10) :
        date[1] = '0'+ date[1]
    if(int(date[0]) < 10) :
        date[0] = '0' + date[0]
    print(f"{date[2]}-{date[0]}-{date[1]}")


main()