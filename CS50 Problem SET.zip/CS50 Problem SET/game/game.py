import random
import sys


def main():
    data()

def data():
        try :
            lev = int(input("Level: "))
            while lev < 0:
                lev = int(input("Level: "))
            y = random.randint(1,lev)
            output(y)
        except ValueError :
            data()

def output(y):
    try:
        guess = int(input("Guess: "))
        while guess != y:
            if guess > y :
                print('Too large!')
            elif guess < y :
                print('Too small!')
            guess = int(input("Guess: "))
        sys.exit("Just right!")
    except ValueError :
        output(y)


main()


