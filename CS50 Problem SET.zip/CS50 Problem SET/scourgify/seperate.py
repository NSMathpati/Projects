import csv

with open("names.csv") as file:
    reader = csv.reader(file)
    for name in reader:

        row = name[0].strip().split(",")
        if (len(row) < 2):
            first = row[0]
        else:
            first,last = row[1].strip(),row[0].strip()