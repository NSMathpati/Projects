import sys
import csv

values = []
def main():
    if len(sys.argv) < 3 :
        sys.exit("Too few command-line arguments")
    elif len(sys.argv) > 3 :
        sys.exit("Too many command-line arguments")
    else :
        ext1,ext2 = sys.argv[1],sys.argv[2]
        check1,check2 = ext1.rstrip().split("."),ext2.rstrip().split(".")
        if check1[1] != "csv" or check2[1] != "csv":
            sys.exit("Not a CSV file")
        else :
            with open(ext1, "r") as file1 :
                reader = csv.DictReader(file1)
                for row in reader:
                    split_name = row["name"].split(",")
                    values.append({"first":split_name[1].lstrip(), "last":split_name[0], "house":row["house"]})
            with open(sys.argv[2],"w") as file2:
               writer = csv.DictWriter(file2, fieldnames = ["first", "last" , "house"])
               writer.writerow({"first": "first", "last":"last","house":"house"})
               for r in values:
                    writer.writerow({"first": r["first"], "last":r["last"], "house": r["house"]})


if __name__ == "__main__":
    main()