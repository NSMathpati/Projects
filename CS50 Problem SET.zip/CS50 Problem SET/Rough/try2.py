from datetime import date
import inflect

d = input("Date: ")

if date.fromisoformat(d):
    byear,bmonth,bday = d.split("-")
t = date.today()
#tyear,tmonth,tday = t.split("-")
print(t)
year =  t.year- int(byear)
month = t.month - int(bmonth)
days = t.day - int(bday)

min = (((year*12) + month) * 730 * 60) + (days*24*60)
p = inflect.engine()
print(f"{p.number_to_words(min)} minutes.")

