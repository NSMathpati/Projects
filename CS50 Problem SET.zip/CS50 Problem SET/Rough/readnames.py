with open("names.txt","r") as file:
    lines = file.readlines()
