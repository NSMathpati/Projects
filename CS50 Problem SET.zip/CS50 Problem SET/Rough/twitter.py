import re

url = input("What is your twitter url: ").strip()

username = re.search("^(https?://)?(www\.)?twitter\.com/(\w+)",url)
print(f"Username : {username.group(3)}")