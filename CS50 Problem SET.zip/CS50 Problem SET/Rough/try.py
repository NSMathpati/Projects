from datetime import date

d = input("Date: ")
birthyear = int(input("year: "))
if date.fromisoformat(d):
    year,month,day = d.split("-")
    print(int(year) - birthyear)