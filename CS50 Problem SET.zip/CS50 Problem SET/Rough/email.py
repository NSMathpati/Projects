#import jsonschema
#from jsonschema import validate
import validators

email_address = validators.email('test@domain.dev')
print(email_address)