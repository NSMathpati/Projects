def hello(name):
    print(f"Hello {name}, nice to meet you!")

def goodbye(name):
    print(f"Goodbye {name}, it was nice to seeing you in here!")

def main():
    x = input()
    hello(x)
    goodbye(x)

if __name__ == "__main__":
    main()