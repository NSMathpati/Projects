class Student:
    def __init__(self,name,address,age,total):
        if not name:
            raise ValueError("Name not entered, Empty string")
        self.name = name
        if address not in ["UK", "US", "India","Canada","Japan"]:
            raise ValueError("Address invalid")
        self.address = address
        #if (int(age).is_integer() == False):
           # raise ValueError("Not an integer")
        self.age = age
        self.total = total

    def __str__(self):
        return f"My name is {self.name}, i am {self.age} years old. I live in {self.address} and i scored {self.total}% in my finals!"

    @classmethod
    def get(cls):
        name = input("Name: ")
        address = input("Address: ")
        age = input("Age: ")
        total = input("Percentage: ")
        return cls(name, address, age, total)

def main():
    student = Student.get()
    print(student)

if __name__ == "__main__":
    main()