import re

email = input("What is your email? ").strip()

if re.search(r"^\w+@(\w+\.)?\w+\.(com|org|edu|in)$", email, re.IGNORECASE):
    print("Valid")
else:
    print("Not valid")