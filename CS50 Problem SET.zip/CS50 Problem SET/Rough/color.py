import csv

names = []

with open("color.csv") as file:
    reader = csv.DictReader(file)
    for _ in reader:
        colors = {"name": _["name"], "color": _["color"]}
        names.append(colors)

#def get_name(colors):
 #   return colors["name"]

for colors in sorted (names, key = lambda colors: colors['name']):
    print(f"{colors['name']}'s favourite color is {colors['color']}")