#include <stdio.h>
#include <cs50.h>

typedef struct
{
    string name;
    string address;
    string number;
}
person;

int main(void)
{
    person people[10];
    int n = get_int("How many people do you have in your phonebook: ");
    for (int i = 0; i < n; i++)
    {
        people[i].name = get_string("What is your name       : ");
        people[i].address = get_string("Enter your address   : ");
        people[i].number = get_string("And your phone number : ");
    }

    for (int i = 0; i < n; i++)
    {
        printf("Name: %s - Address: %s - Phone number: %s\n", people[i].name, people[i].address, people[i].number);
    }
    return 0;

}