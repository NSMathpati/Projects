import csv

date = input("Enter your date: ")
todo = input("Enter your task: ")

with open("list.csv", "a") as file:
    writer = csv.DictWriter(file,fieldnames = ["date","todo"])
    writer.writerow({"date": date,"todo":todo})