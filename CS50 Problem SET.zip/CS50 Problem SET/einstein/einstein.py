# Defining main function to take mass as input from user
def main() :
    mass = int(input("m: "))

    #calling the function to calculate the value of engery E according to einstein's formula
    print("E:",formula(mass))

# Defining a function to calculate and return the value of energy 
def formula(n) :
    c = 3 * pow(10,8)
    return n * pow(c,2)

main()