def main() :
    string = input("Extension: ")
    convert(string)

def convert(answer) :
    answer = answer.split('.')
    if len(answer) < 2:
        print("application/octet-stream")
    else :
        x = answer[-1].lower().strip()
        if x == 'jpg' or x == 'jpeg' :
            print("image/jpeg")
        elif x == 'gif' or x == 'png' :
            print(f"image/{x}")
        elif x == 'pdf' or x == 'zip':
            first_text = 'application'
            print(f"{first_text}/{x}")
        elif x == 'txt' :
            first_text = 'text'
            print(f"{first_text}/plain")
        else :
            print("application/octet-stream")

main()