from fpdf import FPDF

class PDF():
    def __init__(self,name):
        self.new_pdf = FPDF()
        self.new_pdf.add_page()
        self.new_pdf.set_font("helvetica", "B", 15)
        self.new_pdf.cell(30, 10, "CS50 Shirtificate",align = "c")
        self.new_pdf.image("shirtificate.png", x=50, y=50)
        self.new_pdf.text(x = 50, y = 50, txt = f"{name} took CS50")


    def save(self,name):
        self.new_pdf.output(name)



name = input("Enter your  name: ")

pdf = PDF(name)
pdf.save("shirtificate.pdf")