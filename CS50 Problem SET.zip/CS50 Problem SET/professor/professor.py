import random

def main():
    num = get_level()
    tries = 1
    scores = 10
    for i in range(0,10):
        first = generate_integer(num)
        sec = generate_integer(num)
        print(str(first) + " + " + str(sec) + " = ", end = "")
        answer = int(input())
        while answer != (first + sec):
            print("EEE")
            print(str(first) + " + " + str(sec) + " = ", end = "")
            answer = int(input())
            tries += 1
            if tries == 3 :
                print(str(first) + " + " + str(sec) + " = ", end = "")
                print(first + sec)
                scores -= 1
                break

    print(scores)

def get_level():
    try:
        lev = int(input("Level: "))
        while lev > 3 or lev < 1 :
            lev = int(input("Level: "))
        return lev
    except ValueError:
        get_level()

def generate_integer(level):
    if level == 1 :
        return random.randint(0,9)
    elif level == 2 :
        return random.randint(10,99)
    else :
        return random.randint(100,999)



if __name__ == "__main__":
    main()