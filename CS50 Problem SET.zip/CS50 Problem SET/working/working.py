import re
import sys


def main():
    print(convert(input("Hours: ")))


def convert(s):
    found = re.search(r"([0-9][0-2]?):?([0-5][0-9])? ([A-P]M) to ([0-9][0-2]?):?([0-5][0-9])? ([A-P]M)",s)
    if found:
        time = found.groups()
        count = 0
        for i in time :
            if i == None:
                count += 1
        if count == 2 :
            start = int(time[0])
            end = int(time[3])
            if time[5] == 'PM' and end != 12:
                end = end + 12
            if time[2] == 'PM' and start != 12:
                start += 12
            if time[5] == 'AM' and end == 12:
                end = 0
            if time[2] == 'AM' and start == 12:
                start = 0
            nstart = str(start)
            nend = str(end)
            if start < 10:
                nstart = "0"+str(start)
            if end < 10:
                nend = "0"+str(end)
            return f"{nstart}:00 to {nend}:00"

        else:
            start = int(time[0])
            end = int(time[3])
            startc = (time[1])
            endc = (time[4])
            if time[5] == 'PM' and end != 12:
                end = end + 12
            if time[2] == 'PM' and start != 12:
                start += 12
                nstart = str(start)
            if time[5] == 'AM' and end == 12:
                end = 0
            if time[2] == 'AM' and start == 12:
                start = 0
            nend = str(end)
            if start < 10:
                nstart = "0"+str(start)
            if end < 10:
                nend = "0"+str(end)
            return f"{nstart}:{startc} to {nend}:{endc}"
    else:
        raise ValueError

if __name__ == "__main__":
    main()