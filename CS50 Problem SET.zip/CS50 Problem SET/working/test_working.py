from working import convert
import pytest

def test_workingerror():
    with pytest.raises(ValueError):
        convert("9 AM - 5 PM")
        convert("10:7 AM - 5:1 PM")
        convert ("cat")
        convert ("7 - 5")
def test_wrongformat():
    with pytest.raises(ValueError):
        convert("9 to 5")

def test_outof_range():
    with pytest.raises(ValueError):
        convert("25 AM to 56 PM")

def test_working_fine():
    assert convert("12 AM to 12 PM") == "00:00 to 12:00"
    assert convert("8:00 PM to 8:00 AM") == "20:00 to 08:00"
