#include <cs50.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

int main(int argc, string argv[])
{
    if (argc != 2) // Checks for Number of arguments passed in the comman line.
    {
        printf("Usage: ./caesar key\n");
        return 1;
    }
    for (int i = 0; i < strlen(argv[1]); i++) // Checks if the given arguments contains both numbers and alphabets
    {
        if (isalpha(argv[1][i]))
        {
            printf("Usage: ./caesar key\n");
            return 1;
        }
    }
    int key = atoi(argv[1]); // Converts string into an integer
    if (key == 0 || argc > 2)
    {
        printf("Usage: ./caesar key\n");
        return 1;
    }
    else
    {
        string text = get_string("Plaintext:  ");
        int n = strlen(text);
        printf("Ciphertext: ");
        for (int i = 0; i < n; i++)
        {
            if (islower(text[i])) // Checks if its lowercase and runs accordingly
            {
                int c = text[i] + key;
                while (c > 122)
                {
                    c = c - 26;
                    //printf("%c",c);
                }
                printf("%c", c);
            }
            else if (isupper(text[i])) // Checks if its uppercase
            {
                int c = text[i] + key;
                while (c > 90)
                {
                    c = c - 26;
                }
                printf("%c", c);
            }
            else // If its no an alphabets it prints just as the input was given.
            {
                printf("%c", text[i]);
            }
        }
        printf("\n");
        return 0;
    }
}
