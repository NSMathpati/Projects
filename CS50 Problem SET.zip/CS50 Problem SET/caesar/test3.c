#include <cs50.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

int main(int argc, string argv[])
{
    int n = strlen(argv[1]);
    int key = atio(argv[1])
    for ( int i = 0; i < n; i++)
    {
        if(key[i])
    }
}