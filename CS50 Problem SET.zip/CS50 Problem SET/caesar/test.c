#include <cs50.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, string argv[])
{
    int key = atoi(argv[1]);
    printf("%s\n",argv[1]);
    if (key != true && argc > 2)
    {
        printf("usage : ./cipher key\n");
    }
    else
    {
        string original = get_string("Plaintext:  ");
        int numb = strlen(original);
        char text;
        printf("ciphertext: ");
        for (int i = 0; i < numb; i++)
        {
            text = (original[i]+key);
            if ( text > 122)
            {
                text = text - 26;
                printf("%c",text,text);
            }
            else if ( text < 65)
            {
                text = text + 26;
            }
            printf("%c",text);
        }
        printf("\n");
    }
}