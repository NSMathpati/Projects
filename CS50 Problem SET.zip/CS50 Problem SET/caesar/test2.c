#include <cs50.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

int main(int argc, string argv[])
{
    if (argc != 2)
    {
        printf("Usage: ./caesar key\n");
        return 1;
    }
    for(int i = 0; i <strlen(argv[1]); i++)
    {
        if(isalpha(argv[1][i]))
        {
            printf("Usage: ./caesar key\n");
            return 1;
        }
    }
    int key = atoi(argv[1]);
    if(key == 0 || argc > 2 )
    {
        printf("Usage: ./caesar key\n");
        return 1;
    }
    else
    {
        string text = get_string("Plaintext:  ");
        int n = strlen(text);
        printf("Ciphertext: ");
        for (int i = 0; i < n; i++)
        {
            if(islower(text[i]))
            {
                int c = text[i] + key;
                while(c > 122)
                {
                    c = c - 26;
                    //printf("%c",c);
                }
                printf("%c",c);
            }
            else if (isupper(text[i]))
            {
                int c = text[i] + key;
                while( c > 90)
                {
                    c = c - 26;
                }
                printf("%c",c);
            }
            else
            {
                printf("%c",text[i]);
            }
        }
        printf("\n");
        return 0;
    }
}
