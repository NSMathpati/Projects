def main():
    plate = input("Plate: ")
    if is_valid(plate):
        print("Valid")
    else:
        print("Invalid")


def is_valid(s):
    x = [' ', '-', '_', '.']
    if s[0].isnumeric() or len(s) < 2 or len(s) > 6 :
        return False
    else  :
        n = len(s)/2
        for i in range(0,len(s)) :
            if s[i] == "_" or s[i] == " " or s[i] == "-" or s[i] == "." :
                return False
                break
            elif s[i].isnumeric():
                x = s[i:len(s)-1]
                for k in range(0,len(x)) :
                    if x[0] == '0' :
                        return False

                for j in range (i+1,len(s)-i) :
                    if s[j].isalpha():
                        break
                    return False

        if s[int(n)].isnumeric() and s[-1].isalpha() :
            return False
        elif s[0:2].isalpha() :
            return True
        else :
            return True



main()