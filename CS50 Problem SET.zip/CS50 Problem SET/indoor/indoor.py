# Ask user for text
capital_text = input()

# Convert input text to lower case
lowercase_text = capital_text.lower()

# print the lowercase text
print(lowercase_text)