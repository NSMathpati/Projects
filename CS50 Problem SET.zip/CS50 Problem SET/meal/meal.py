def main() :
    time = input("Enter time: ")
    x = convert(time)
    if x >= 7.0 and x <= 8.0 :
        print('Breakfast time')
    elif x >= 12.0 and x <= 13.0 :
        print('Lunch time')
    elif x >= 18.0 and x <= 19.0 :
        print('Dinner time')


def convert(x):
    x = x.split(':')
    if 'a.m' in x[1] :
        x[1] = x[1].replace('a.m',"")
        hours = float(x[0])
        minutes = float(x[1])
        min_conv = minutes/60
        converted_time = hours + min_conv
    elif 'p.m' in x[1] :
        x[1] = x[1].replace('p.m',"")
        hours = float(x[0])
        minutes = float(x[1])
        min_conv = minutes/60
        converted_time = hours + min_conv + 12.0
    else :
        hours = float(x[0])
        minutes = float(x[1])
        min_conv = minutes/60
        converted_time = hours + min_conv
    return converted_time


main()