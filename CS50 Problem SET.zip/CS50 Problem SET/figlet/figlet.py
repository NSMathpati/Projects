import pyfiglet
import sys

fonts = pyfiglet.FigletFont.getFonts()
if len(sys.argv) < 2 :
    text = input("Input: ")
    converted_text = pyfiglet.figlet_format(text)
    print(converted_text)
elif len(sys.argv) == 3 :
    x = sys.argv[2]
    if sys.argv[1] != '-f' or x not in fonts :
        sys.exit("Invalid usage")
    else:
        text = input("Input: ")
        converted_text = pyfiglet.figlet_format(text,font = x)
        print(converted_text)
else:
    sys.exit("Invalid usage")