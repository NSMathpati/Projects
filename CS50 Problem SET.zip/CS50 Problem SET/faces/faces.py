text = input()
text = text.replace(":)","🙂")
text = text.replace(":(","🙁")
print(text)