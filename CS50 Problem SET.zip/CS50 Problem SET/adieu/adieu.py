import sys
try :
    names = []
    text = "Adieu, adieu, to "

    while True:
        name = input()
        names.append(name)
except EOFError:
    length = len(names)
    if length == 2 :
        text += names[0] + " and " + names[1]
    else:
        for i in range(0,length):
            if i == length - 2:
                text += names[i] + ", and "
            elif i == length - 1 :
                text += names[i]

            else :
                text += names[i] + ", "
    print(text)




