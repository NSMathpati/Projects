from datetime import date
import inflect
import sys


def main():
    dob = get_dob()
    minutes = convert(dob)
    text_minutes = convert_text(minutes)
    print(text_minutes.capitalize())

#defining a function to get the birth date
def get_dob():
    _date = input("Date of Birth: ")
    # To try if the given input is of correct format
    try:
        validate = date.fromisoformat(_date)
        return validate
    # Exits if the given date is not of the correct format which is yyyy-mm-dd
    except ValueError:
        sys.exit("Invalid date")

def convert(dob):
    tday = date.today()
    min = (tday - dob)
    return min.days * 24 * 60


def convert_text(min):
    x = inflect.engine()
    word = x.number_to_words(min,andword="")
    return f"{word} minutes"

if __name__ == "__main__":
    main()