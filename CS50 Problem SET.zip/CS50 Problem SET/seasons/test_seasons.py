from seasons import convert_text

def test_convert():
    assert convert_text(525600) == "five hundred twenty-five thousand, six hundred minutes"