from random import choice


y = choice(['Heads', 'Tails'])
x = input("What's you call: ")
print(f"Its a {y}")
if (x==y):
    print('You win!')
else :
    print('You lost!')