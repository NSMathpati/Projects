def main() :
    name = input("Enter first tweet: ")
    print(shorten (name))



def shorten(x) :
    acrynm = ""
    for i in range(0,len(x)) :
        if x[i] == 'A' or x[i] == 'E' or x[i] == 'I' or x[i] == 'O' or x[i] =='U':
            continue
        elif x[i] == 'a' or x[i] == 'e' or x[i] == 'i' or x[i] == 'o' or x[i] =='u':
            continue
        else :
            acrynm += x[i]
    return acrynm


if __name__ == "__main__":
    main()


