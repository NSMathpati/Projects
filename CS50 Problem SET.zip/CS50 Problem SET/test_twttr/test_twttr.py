from twttr import shorten

def test_convert():
    assert shorten("testing") == "tstng"
    assert shorten("UPPERCASE") == "PPRCS"
    assert shorten("this is my tweet") == "ths s my twt"
    assert shorten("s0meth1ng") == "s0mth1ng"
    assert shorten("What's your name?") == "Wht's yr nm?"