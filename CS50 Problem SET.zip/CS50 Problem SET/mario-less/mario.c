#include<cs50.h>
#include<stdio.h>
// Function to create the required pyramid.
void marioless(int height)
{
    // A set of nested loops that runs according to the pattern we would like to see.
    for (int i = height; i > 0; i--)
    {
        for (int j = 1; j < i; j++)
        {
            printf(" ");
        }
        for (int k = height; k >= i; k --)
        {
            printf("#"); // Prints #'s like pyramid
        }
        printf("\n");
    }
}

int main(void)
{
    // asking user for input , like the height of the pyramid he would like to see
    int pyheight = get_int("What is the height of the pyramid?\n");
    if (pyheight >= 1 && pyheight <= 8)// Checks if the given user input is within range
    {
        marioless(pyheight);
    }
    else
    {
        // Loop to promt user for input, if the user input is not within the range
        while (pyheight < 1 || pyheight > 8)
        {
            int newheight = get_int("What is the height of the pyramid>\n");
            // Checks again if the user input is within range
            if (newheight >= 1 && newheight <= 8)
            {
                marioless(newheight);
                break;// Exits the loop if the new height given by the user is within range.
            }
            // If not the loop continues and the loop promts the user for new input over and over again
            else
            {
                continue;
            }
        }
    }
}