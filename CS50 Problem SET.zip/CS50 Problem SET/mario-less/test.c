#include <cs50.h>
#include <stdio.h>

int main(void)
{
    int height;
    do
    {
         height = get_int("What is the height of the pyramid?\n");

    }while(height<1 || height>8);
}